#ifndef StepperCNC
#define StepperCNC
#include <Arduino.h>
//funzioni esterne:
void  preinit(int flag_pin, int flag2_pin, int poweron);
bool  restore();
void  set_pin(int pin_mot, int pin_led, int pin_led_testa, int pin_laser);
void  set_interrupt(int pin_schermo, int pin_check12v);
void  set_fans(int p_sonda, int p_ventole, int p_T_TEMP_OFF, int p_T_TEMP_ON, int p_SOGLIA_TEMP);
void  pwm_mot(int campione);
void  att_luci(int stato);
void  att_luci_testa(int stato);
void  att_laser(int stato);
void  setexp(int sda, int scl, int adress_expander);
void check_fans();
void  blkmot(bool en);
void  s0xy(float velocita);
void  s0zz(float velocita);
float s0pz(float velocita);
void  movxyz(float velocita, float pasx, float pasy, float pasz); //movxyz(mm/s, mm, mm, mm);
void  delayS(int millisecondi);
//funzioni interne:
float inviomovimento(uint8_t v1, float v2, float v3, float v4, float v5);
float inviomovimento_ex(uint8_t v1, float v2, float v3, float v4, float v5);
void  controllo_interrupt();
void  blocco(int tipo);
#endif
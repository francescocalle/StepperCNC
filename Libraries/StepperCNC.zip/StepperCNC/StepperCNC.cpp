#include <StepperCNC.h>
#include <Wire.h>
#include <Nextion.h>
//pin finecorsa, enable e gpio
int pwm_pin=0, led_pin=0, led_testa_pin=0, laser_pin=0, schermo_pin=0, check12v_pin=0, flag=0, flag2=0, power=0, sonda=0, ventole=0, T_TEMP_OFF=0, T_TEMP_ON=0, SOGLIA_TEMP=0, temp = 0, caldo = 1, track = 0;
unsigned long t_temp = 0;
//indirizzo expander, valori motore e dimensioni area
int adress=0, percentuale_pwm=0;
//controllo attivazioni
bool att_exp=0, att_pwm=0, att_interrupt=0, blk=0, att_fans=0;
typedef struct{
  uint8_t  id;
  float    a;
  float    b;
  float    c;
  float    d;
} Packet;
typedef struct{
  int      v;
  float    d;
} Packet2;
Packet  tx;
Packet2 rx;
//inizializzazione funzioni  a schermo
NexVariable pagine1 = NexVariable(0, 0, "pagine");
NexVariable b_pres1 = NexVariable(0, 0, "bpress");
NexPage errore_1    = NexPage(0, 0, "errore1");
NexPage errore_2    = NexPage(0, 0, "errore2");
NexPage errore_3    = NexPage(0, 0, "errore3");
NexPage home1       = NexPage(0, 0, "schermatahome");
NexPage process1    = NexPage(0, 0, "process");
//funzione reset blocco:
void  preinit(int flag_pin, int flag2_pin, int poweron){
  flag = flag_pin;
  flag2 = flag2_pin;
  power = poweron;
  pinMode(flag   ,  INPUT);
  pinMode(flag2  , OUTPUT);
  pinMode(power,   OUTPUT);
  digitalWrite(flag2, 0);
  digitalWrite(poweron, 0);
  delay(1000);
  digitalWrite(poweron, 1);
  delay(1000);
}
bool  restore(){
  bool old_blk = blk;
  blk = 0;
  return old_blk;
}
//funzioni set gpio:
void  set_pin(int pin_mot, int pin_led, int pin_led_testa, int pin_laser){
  pwm_pin = pin_mot;
  led_pin = pin_led;
  led_testa_pin = pin_led_testa;
  laser_pin = pin_laser;
  pinMode(pwm_pin,       OUTPUT);
  pinMode(led_pin,       OUTPUT);
  pinMode(led_testa_pin, OUTPUT);
  pinMode(laser_pin,     OUTPUT);
  analogWrite(pwm_pin,        0);
  digitalWrite(led_pin,       0);
  digitalWrite(led_testa_pin, 0);
  digitalWrite(laser_pin,     0);
  att_pwm = 1;
}
void  set_interrupt(int pin_schermo, int pin_check12v){
  schermo_pin = pin_schermo;
  check12v_pin = pin_check12v;
  pinMode(schermo_pin,  INPUT);
  pinMode(check12v_pin, INPUT);
  att_interrupt = 1;
}
void  set_fans(int p_sonda, int p_ventole, int p_T_TEMP_OFF, int p_T_TEMP_ON, int p_SOGLIA_TEMP){
  sonda = p_sonda;
  ventole = p_ventole;
  T_TEMP_OFF = p_T_TEMP_OFF;
  T_TEMP_ON = p_T_TEMP_ON;
  SOGLIA_TEMP = p_SOGLIA_TEMP;
  pinMode(sonda, INPUT);
  pinMode(ventole, OUTPUT);
  att_fans = 1;
}
//funzioni di attivazione gpio:
void  setexp(int sda, int scl, int adress_expander){
  adress = adress_expander;
  Wire.begin(sda, scl);
  att_exp = 1;
  rx.v = 0;
  rx.d = 0;
  track = 0;
}
void  pwm_mot(int campione){
  if(blk == 1 || att_pwm == 0 || campione < 0 || campione > 100){
    return;
  }
  percentuale_pwm = campione;
  percentuale_pwm = map(percentuale_pwm, 0, 100, 0, 255);
  if(percentuale_pwm == 0){
    analogWrite(pwm_pin, 0);
  }else{
    controllo_interrupt();
    analogWrite(pwm_pin, percentuale_pwm);
  }
}
void  att_luci(int stato){
  if(att_pwm == 0 || stato < 0 || stato > 1){
    return;
  }
  digitalWrite(led_pin, stato);
}
void  att_luci_testa(int stato){
  if(att_pwm == 0 || stato < 0 || stato > 1){
    return;
  }
  digitalWrite(led_testa_pin, stato);
}
void  att_laser(int stato){
  if(att_pwm == 0 || stato < 0 || stato > 1){
    return;
  }
  digitalWrite(laser_pin, stato);
}
//funzioni di movimento dei motori:
void  check_fans(){
  if(att_fans == 0){
    return;
  }
  temp = analogRead(sonda);
  if (temp < SOGLIA_TEMP) {
    caldo = 2;
    digitalWrite(ventole, 1);
  }
  if (caldo == 2) {
    if (temp > (SOGLIA_TEMP + 100)) {
      caldo = 0;
      digitalWrite(ventole, 0);
      t_temp = millis();
    }
  } else {
    if (caldo == 0 && (millis() - t_temp) >= (T_TEMP_OFF * 1000)) {
      caldo = 1;
      digitalWrite(ventole, 1);
      t_temp = millis();
    }
    if (caldo == 1 && (millis() - t_temp) >= (T_TEMP_ON * 1000)) {
      caldo = 0;
      digitalWrite(ventole, 0);
      t_temp = millis();
    }
  }
}
void  blkmot(bool en) {
  if(att_exp == 0){
    return;
  }
  if(en==1){
    inviomovimento(5, 1, 0, 0, 0);
  }else{
    inviomovimento_ex(5, 0, 0, 0, 0);
  }
}
void  s0xy(float velocita) {
  //abilitazione pin per movimento
  controllo_interrupt();
  if(blk == 1 || velocita <= 0 || att_exp == 0){
    return;
  }
  inviomovimento(2, velocita, 0, 0, 0);
}
void  s0zz(float velocita) {
  //abilitazione pin per movimento
  controllo_interrupt();
  if(blk == 1 || velocita <= 0 || att_exp == 0){
    return;
  }
  inviomovimento(1, velocita, 0, 0, 0);
}
float s0pz(float velocita) {
  //abilitazione pin per movimento
  controllo_interrupt();
  if(blk == 1 || velocita <= 0 || att_exp == 0){
    return 0;
  }
  float val = -1.0;
  track++;
  val = inviomovimento(3, velocita, track, 0, 0);
  return val;
}
void  movxyz(float velocita, float pasx, float pasy, float pasz) { //movxyz(mm/min, mm, mm, mm);
  //abilitazione pin per movimento
  controllo_interrupt();
  if(blk == 1 || velocita <= 0 || att_exp == 0){
    return;
  }
  inviomovimento(4, velocita, pasx, pasy, pasz);
}
void  delayS(int millisecondi){
  if(blk == 1){
    return;
  }
  if(millisecondi <= 0){
    return;
  }
  while(millisecondi > 0 && !blk){
    controllo_interrupt();
    delay(1);
    millisecondi--;
  }
}
float inviomovimento(uint8_t v1, float v2, float v3, float v4, float v5){
  if(digitalRead(flag)==1){
    tx.id = 0;
    tx.a  = 0;
    tx.b  = 0;
    tx.c  = 0;
    tx.d  = 0;
    Wire.beginTransmission(adress);
    Wire.write((uint8_t*)&tx, sizeof(Packet));
    Wire.endTransmission();
  }
  while(digitalRead(flag)==1){
    vTaskDelay(1);
    check_fans();
  }
  controllo_interrupt();
  if(blk == 1){
    return 0;
  }
  tx.id = v1;
  tx.a  = v2;
  tx.b  = v3;
  tx.c  = v4;
  tx.d  = v5;
  Wire.beginTransmission(adress);
  Wire.write((uint8_t*)&tx, sizeof(Packet));
  Wire.endTransmission();
  while(digitalRead(flag)==0){
    vTaskDelay(1);
    check_fans();
    controllo_interrupt();
    if(blk == 1){
      tx.id = 0;
      tx.a  = 0;
      tx.b  = 0;
      tx.c  = 0;
      tx.d  = 0;
      Wire.beginTransmission(adress);
      Wire.write((uint8_t*)&tx, sizeof(Packet));
      Wire.endTransmission();
      return 0;
    }
  }
  tx.id = 0;
  tx.a  = 0;
  tx.b  = 0;
  tx.c  = 0;
  tx.d  = 0;
  Wire.beginTransmission(adress);
  Wire.write((uint8_t*)&tx, sizeof(Packet));
  Wire.endTransmission();
  if (v1 == 3) {
    while(track != rx.v){
      vTaskDelay(1);
      check_fans();
      Wire.requestFrom(adress, sizeof(Packet2));
      while (Wire.available() < sizeof(Packet2)){
        vTaskDelay(1);
        check_fans();
      }
      Wire.readBytes((uint8_t*)&rx,sizeof(Packet2));
      delayS(1000);
    }
    return rx.d;
  }
  return 0;
}
float inviomovimento_ex(uint8_t v1, float v2, float v3, float v4, float v5){
  if(digitalRead(flag)==1){
    tx.id = 0;
    tx.a  = 0;
    tx.b  = 0;
    tx.c  = 0;
    tx.d  = 0;
    Wire.beginTransmission(adress);
    Wire.write((uint8_t*)&tx, sizeof(Packet));
    Wire.endTransmission();
  }
  while(digitalRead(flag)==1){
    vTaskDelay(1);
    check_fans();
  }
  tx.id = v1;
  tx.a  = v2;
  tx.b  = v3;
  tx.c  = v4;
  tx.d  = v5;
  Wire.beginTransmission(adress);
  Wire.write((uint8_t*)&tx, sizeof(Packet));
  Wire.endTransmission();
  while(digitalRead(flag)==0){
    vTaskDelay(1);
    check_fans();
  }
  tx.id = 0;
  tx.a  = 0;
  tx.b  = 0;
  tx.c  = 0;
  tx.d  = 0;
  Wire.beginTransmission(adress);
  Wire.write((uint8_t*)&tx, sizeof(Packet));
  Wire.endTransmission();
  if (v1 == 3) {
    while(track != rx.v){
      vTaskDelay(1);
      check_fans();
      Wire.requestFrom(adress, sizeof(Packet2));
      while (Wire.available() < sizeof(Packet2)){
        vTaskDelay(1);
        check_fans();
      }
      Wire.readBytes((uint8_t*)&rx,sizeof(Packet2));
      delayS(1000);
    }
    return rx.d;
  }
  return 0;
}
void  controllo_interrupt(){
  if(blk == 1 || att_interrupt == 0 || att_exp == 0){
    return;
  }
  if(digitalRead(check12v_pin) == 0){
    delay(2);
    if(digitalRead(check12v_pin) == 0){
      delay(2);
      if(digitalRead(check12v_pin) == 0){
        blocco(1);
      }
    }
  }
  if(digitalRead(schermo_pin) == 1){
    delay(2);
    if(digitalRead(schermo_pin) == 1){
      delay(2);
      if(digitalRead(schermo_pin) == 1){
        blocco(2);
      }
    }
  }
}
void  blocco(int tipo){
  analogWrite(pwm_pin, 0);
  digitalWrite(flag2, 1);
  blk = 1;
  delay(100);
  uint32_t val = 0;
  uint32_t pag = 0;
  switch (tipo){
    case 1:
      errore_1.show();
      delay(500);
      while(digitalRead(check12v_pin) == 0 || val == 0){
        vTaskDelay(1);
        pagine1.getValue(&pag);
        if(pag != 18){
          errore_1.show();
          delay(500);
        }
        b_pres1.getValue(&val);
        if(val == 1){
          b_pres1.setValue(0);
        }
      }
      process1.show();
      break;
    case 2:
      errore_2.show();
      delay(500);
      while(digitalRead(schermo_pin) == 1 || val == 0){
        vTaskDelay(1);
        check_fans();
        pagine1.getValue(&pag);
        if(pag != 19){
          errore_2.show();
          delay(500);
        }
        b_pres1.getValue(&val);
        if(val > 0){
          b_pres1.setValue(0);
          if(val == 1){
            blk = 1;
          }
          if(val == 2){
            blk = 0;
          }
        }
      }
      process1.show();
      if(blk == 0 && percentuale_pwm > 0){
        analogWrite(pwm_pin, percentuale_pwm);
        delay(3000);
      }
      break;
    default:
      errore_3.show();
      delay(500);
      while(digitalRead(check12v_pin) == 0 || val == 0){
        vTaskDelay(1);
        pagine1.getValue(&pag);
        if(pag != 20){
          errore_3.show();
          delay(500);
        }
        b_pres1.getValue(&val);
        if(val == 1){
          b_pres1.setValue(0);
        }
      }
      home1.show();
      break;
  }
  if(blk == 1){
    digitalWrite(power, 0);
    delay(1000);
    digitalWrite(power, 1);
  }
  digitalWrite(flag2, 0);
}